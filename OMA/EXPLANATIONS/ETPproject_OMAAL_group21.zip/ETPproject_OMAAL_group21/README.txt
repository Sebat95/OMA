-Our report is in folder Report
-Our program is in folder Program, along side with project and all other code produced
-Our 7 .sol files & benchmark is in folder Results

TO RUN OUR PROGRAM: command line is as requested
		    the instance formulation should be in the same folder
		    also in the same folder should be the three .dll file in the Program folder



Thanks in advance!!!