#ifndef SRC_OMA_LIBRARIES_INITIALIZATION_H_
#define SRC_OMA_LIBRARIES_INITIALIZATION_H_

void initialization(int *x, int **n, int E, int T); // find an initial feasible solution x

#endif /* SRC_OMA_LIBRARIES_INITIALIZATION_H_ */
