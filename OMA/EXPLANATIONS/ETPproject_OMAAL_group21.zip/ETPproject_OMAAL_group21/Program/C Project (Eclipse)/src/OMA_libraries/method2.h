#ifndef SRC_OMA_LIBRARIES_METHOD2_H_
#define SRC_OMA_LIBRARIES_METHOD2_H_

void optimizationMethod2(int *x, int T, int E, int S, int **n, char *instance_name, double ex_time);

#endif /* SRC_OMA_LIBRARIES_METHOD1_H_ */
