In this folder there are all utilities (libraries as well as full compiled programs) we used for scripting, logging and parameters tuning and all the past "tries" for 
achieving the final optimization algorithm.

Furthermore some unused portion of the final source files (found in "Program/C Project (Eclipse)/src") is left there, commented out, this is due or to an improvement 
with a better function or simply beacause we found them experimentally inferior to others.