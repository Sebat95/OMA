#ifndef SRC_OMA_LIBRARIES_METHOD1_H_
#define SRC_OMA_LIBRARIES_METHOD1_H_

void optimizationMethod1(int *x, int T, int E, int S, int **n, int *students_per_exam, char *instance_name);

#endif /* SRC_OMA_LIBRARIES_METHOD1_H_ */
