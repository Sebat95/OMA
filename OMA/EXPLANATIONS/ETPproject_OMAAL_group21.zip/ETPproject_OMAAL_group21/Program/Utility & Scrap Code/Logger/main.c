/*
 * main.c
 *
 *  Created on: 02 gen 2018
 *      Author: Nicola
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void setup(char *instance_name, int *T_P, int *E_P, int *S_P, int ***conflictual_students_P, int **x_P);
void printParameters(int TABU_LENGTH, int MIN_TABU_LENGTH, int MAX_TABU_LENGTH, int N_BEST, double RANDOMNESS_BEST, double RANDOMNESS_BEST_MIN, double RANDOMNESS_BEST_MAX, double TREND_THRESHOLD_BEST_RANDOM_GROUP, int N_BEST_SINGLE, double RANDOMNESS_BEST_SINGLE, double RANDOMNESS_BEST_SINGLE_MIN, double RANDOMNESS_BEST_SINGLE_MAX, double TREND_THRESHOLD_BEST_RANDOM_SINGLE, double RANDOMNESS_RANDOMorCHEAP_GROUP, double RANDOMNESS_RANDOMorCHEAP_GROUP_MIN, double RANDOMNESS_RANDOMorCHEAP_GROUP_MAX, double RANDOMNESS_RANDOMorCHEAP_SINGLE, double RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN, double RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX, double ALFA, double BETA, int ITERATION, int ITERATION_THRESHOLD, int IT_GROUP_BEST_RANDOM, int IT_SINGLE_BEST_RANDOM, int IT_GROUP_RANDOM, int IT_SINGLE_RANDOM, int NO_IMPR_DECREASE, int DESTROY_THRESHOLD, int DESTROY_GROUP, int DESTROY_SINGLE, int N_TIMESLOT, double TEMP_PAR, double DIST_PAR, int SINGLE_DIST, int GROUP_DIST, int ITERATIONS_DIST, int DYNAMIC_PARAMETERS, int DYNAMIC_TABULIST, int TABULIST_INCREASING, int DYNAMIC_RANDOMNESS_SINGLE, int RANDOMNESS_SINGLE_INCREASING, int DYNAMIC_RANDOMNESS_GROUP, int RANDOMNESS_GROUP_INCREASING, int DYNAMIC_RANDOMorCHEAP_SINGLE, int RANDOMorCHEAP_SINGLE_INCREASING, int DYNAMIC_RANDOMorCHEAP_GROUP, int RANDOMorCHEAP_GROUP_INCREASING, int DESTROY_CURRENTorBEST, int DESTROY_BESTFIRSTorRANDOM);
void configure(int* min_destroy_threshold, int* max_destroy_threshold,		int* incr_destroy_thresold, int* min_min_tabu_length,		int* max_min_tabu_length, int* incr_min_tabu_length,		int* min_max_tabu_length, int* max_max_tabu_length,		int* incr_max_tabu_length, int* min_destroy_currentorbest,		int* max_destroy_currentorbest, int* min_destroy_bestfirstorrandom,		int* max_destroy_bestrfirstorrandom,		int* min_randomorcheap_single_increasing,		int* max_randomorcheap_single_increasing,		int* min_randomorcheap_group_increasing,		int* max_randomorcheap_group_increasing, int* min_it_group_best_random,		int* max_it_group_best_random, int* incr_it_group_best_random,		int* min_it_single_best_random,		int* max_it_single_best_random,		int* incr_it_single_best_random, double* min_randomness_best_min,		double* max_randomness_best_min, double* incr_randomness_best_min,		double* min_randomness_best_max, double* max_randomness_best_max,		double* incr_randomness_best_max,		double* min_randomness_best_single_min,		double* max_randomness_best_single_min,		double* incr_randomness_best_single_min,		double* min_randomness_best_single_max,		double* max_randomness_best_single_max,		double* incr_randomness_best_single_max,		double* min_randomorcheap_single_min,		double* max_randomorcheap_single_min,		double* incr_randomorcheap_single_min,		double* min_randomorcheap_single_max,		double* max_randomorcheap_single_max,		double* incr_randomorcheap_single_max,		double* min_randomorcheap_group_min,		double* max_randomorcheap_group_min,		double* incr_randomorcheap_group_min,		double* min_randomorcheap_group_max,		double* max_randomorcheap_group_max,		double* incr_randomorcheap_group_max);
double computeBestPenalty(char *sol_name, int *x, int **n, int E, int T, int S);

int main(int argc, char* argv[])
{
	FILE *output;
	int T, E, S, **n, *x;
	double BestPenalty;
	char command[100], sol_name[100], instance_path[100];
	sprintf(command, "OMA_v4 %s %d parameters.txt", argv[1], atoi(argv[2]));
	sprintf(sol_name, "%s_OMAAL_group21.sol", argv[1]);

	sprintf(instance_path, "instances\\%s", argv[1]);

	output=fopen("output.txt", "w");
	if(output==NULL)
	{
		fprintf(stderr, "Errore nell'apertura di output.txt\n");
		exit(3);
	}

	int TABU_LENGTH=10, MIN_TABU_LENGTH=1, MAX_TABU_LENGTH=10;
	int N_BEST=100;
	double RANDOMNESS_BEST=0.1, RANDOMNESS_BEST_MIN=0.05, RANDOMNESS_BEST_MAX=0.2, TREND_THRESHOLD_BEST_RANDOM_GROUP=0.05;
	int N_BEST_SINGLE=200;
	double RANDOMNESS_BEST_SINGLE=0.2, RANDOMNESS_BEST_SINGLE_MIN=0.1, RANDOMNESS_BEST_SINGLE_MAX=0.5, TREND_THRESHOLD_BEST_RANDOM_SINGLE=0.1;
	double RANDOMNESS_RANDOMorCHEAP_GROUP=0.8, RANDOMNESS_RANDOMorCHEAP_GROUP_MIN=0.7, RANDOMNESS_RANDOMorCHEAP_GROUP_MAX=0.9, RANDOMNESS_RANDOMorCHEAP_SINGLE=0.5, RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN=0.5, RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX=0.9;
	double ALFA=0.3, BETA=0.4;
	int ITERATION=100, ITERATION_THRESHOLD=5000;
	int IT_GROUP_BEST_RANDOM=100, IT_SINGLE_BEST_RANDOM=100, IT_GROUP_RANDOM=100, IT_SINGLE_RANDOM=100;
	int NO_IMPR_DECREASE=100;
	int DESTROY_THRESHOLD=500, DESTROY_GROUP=500, DESTROY_SINGLE=500, N_TIMESLOT=3;
	double TEMP_PAR=0.995;
	double DIST_PAR=0.9;
	int SINGLE_DIST=0, GROUP_DIST=1, ITERATIONS_DIST=1000;
	int DYNAMIC_PARAMETERS = 1, DYNAMIC_TABULIST = 1, TABULIST_INCREASING = 1, DYNAMIC_RANDOMNESS_SINGLE = 1;
	int RANDOMNESS_SINGLE_INCREASING = 0, DYNAMIC_RANDOMNESS_GROUP = 0, RANDOMNESS_GROUP_INCREASING = 0;
	int DYNAMIC_RANDOMorCHEAP_SINGLE = 1, RANDOMorCHEAP_SINGLE_INCREASING = 0, DYNAMIC_RANDOMorCHEAP_GROUP = 1, RANDOMorCHEAP_GROUP_INCREASING = 0;
	int DESTROY_CURRENTorBEST = 1, DESTROY_BESTFIRSTorRANDOM = 0;

	int min_destroy_threshold, max_destroy_threshold, incr_destroy_thresold;
	int min_min_tabu_length, max_min_tabu_length, incr_min_tabu_length;
	int min_max_tabu_length, max_max_tabu_length, incr_max_tabu_length;
	int min_destroy_currentorbest, max_destroy_currentorbest;
	int min_destroy_bestfirstorrandom, max_destroy_bestrfirstorrandom;
	int min_randomorcheap_single_increasing, max_randomorcheap_single_increasing;
	int min_randomorcheap_group_increasing, max_randomorcheap_group_increasing;
	int min_it_group_best_random, max_it_group_best_random, incr_it_group_best_random;
	int min_it_single_best_random, max_it_single_best_random, incr_it_single_best_random;
	double min_randomness_best_min, max_randomness_best_min, incr_randomness_best_min;
	double min_randomness_best_max, max_randomness_best_max, incr_randomness_best_max;
	double min_randomness_best_single_min, max_randomness_best_single_min, incr_randomness_best_single_min;
	double min_randomness_best_single_max, max_randomness_best_single_max, incr_randomness_best_single_max;
	double min_randomorcheap_single_min, max_randomorcheap_single_min, incr_randomorcheap_single_min;
	double min_randomorcheap_single_max, max_randomorcheap_single_max, incr_randomorcheap_single_max;
	double min_randomorcheap_group_min, max_randomorcheap_group_min, incr_randomorcheap_group_min;
	double min_randomorcheap_group_max, max_randomorcheap_group_max, incr_randomorcheap_group_max;

	setup(instance_path, &T, &E, &S, &n, &x);
	configure(	 &min_destroy_threshold, &max_destroy_threshold, &incr_destroy_thresold,
			 &min_min_tabu_length, &max_min_tabu_length, &incr_min_tabu_length,
			 &min_max_tabu_length, &max_max_tabu_length, &incr_max_tabu_length,
			 &min_destroy_currentorbest, &max_destroy_currentorbest,
			 &min_destroy_bestfirstorrandom, &max_destroy_bestrfirstorrandom,
			 &min_randomorcheap_single_increasing, &max_randomorcheap_single_increasing,
			 &min_randomorcheap_group_increasing, &max_randomorcheap_group_increasing,
			 &min_it_group_best_random, &max_it_group_best_random, &incr_it_group_best_random,
			 &min_it_single_best_random, &max_it_single_best_random, &incr_it_single_best_random,
			 &min_randomness_best_min, &max_randomness_best_min, &incr_randomness_best_min,
			 &min_randomness_best_max, &max_randomness_best_max, &incr_randomness_best_max,
			 &min_randomness_best_single_min, &max_randomness_best_single_min, &incr_randomness_best_single_min,
			 &min_randomness_best_single_max, &max_randomness_best_single_max, &incr_randomness_best_single_max,
			 &min_randomorcheap_single_min, &max_randomorcheap_single_min, &incr_randomorcheap_single_min,
			 &min_randomorcheap_single_max, &max_randomorcheap_single_max, &incr_randomorcheap_single_max,
			 &min_randomorcheap_group_min, &max_randomorcheap_group_min, &incr_randomorcheap_group_min,
			 &min_randomorcheap_group_max, &max_randomorcheap_group_max, &incr_randomorcheap_group_max);

	fprintf(output, "MIN_TABU_LENGTH,MAX_TABU_LENGTH,RANDOMNESS_BEST_MIN,RANDOMNESS_BEST_MAX,RANDOMNESS_BEST_SINGLE_MIN,RANDOMNESS_BEST_SINGLE_MAX,RANDOMNESS_RANDOMorCHEAP_GROUP_MIN,RANDOMNESS_RANDOMorCHEAP_GROUP_MAX,RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN,RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX,IT_GROUP_BEST_RANDOM,IT_SINGLE_BEST_RANDOM,DESTROY_THRESHOLD,TABULIST_INCREASING,RANDOMNESS_SINGLE_INCREASING,RANDOMNESS_GROUP_INCREASING,RANDOMorCHEAP_SINGLE_INCREASING,RANDOMorCHEAP_GROUP_INCREASING,DESTROY_CURRENTorBEST,DESTROY_BESTFIRSTorRANDOM,BestPenalty\n");

	for(DESTROY_THRESHOLD=min_destroy_threshold; DESTROY_THRESHOLD <= max_destroy_threshold; DESTROY_THRESHOLD+=incr_destroy_thresold)
	for(MIN_TABU_LENGTH = min_min_tabu_length; MIN_TABU_LENGTH <= max_min_tabu_length; MIN_TABU_LENGTH+=incr_min_tabu_length)
		for(MAX_TABU_LENGTH = min_max_tabu_length; MAX_TABU_LENGTH <= max_max_tabu_length; MAX_TABU_LENGTH+=incr_max_tabu_length)
	for(DESTROY_CURRENTorBEST = min_destroy_currentorbest; DESTROY_CURRENTorBEST <= max_destroy_currentorbest; DESTROY_CURRENTorBEST++)
		for(DESTROY_BESTFIRSTorRANDOM = min_destroy_bestfirstorrandom; DESTROY_BESTFIRSTorRANDOM <= max_destroy_bestrfirstorrandom; DESTROY_BESTFIRSTorRANDOM++)
			for(RANDOMorCHEAP_SINGLE_INCREASING=min_randomorcheap_single_increasing; RANDOMorCHEAP_SINGLE_INCREASING<=max_randomorcheap_single_increasing;RANDOMorCHEAP_SINGLE_INCREASING++)
				for(RANDOMorCHEAP_GROUP_INCREASING=min_randomorcheap_group_increasing; RANDOMorCHEAP_GROUP_INCREASING<=max_randomorcheap_group_increasing;RANDOMorCHEAP_GROUP_INCREASING++)
	for(IT_GROUP_BEST_RANDOM=min_it_group_best_random;IT_GROUP_BEST_RANDOM<=max_it_group_best_random;IT_GROUP_BEST_RANDOM+=incr_it_group_best_random)
		for(IT_SINGLE_BEST_RANDOM=min_it_single_best_random;IT_SINGLE_BEST_RANDOM<=max_it_single_best_random;IT_SINGLE_BEST_RANDOM+=incr_it_single_best_random)
	for(RANDOMNESS_BEST_MIN=min_randomness_best_min;RANDOMNESS_BEST_MIN<=max_randomness_best_min+0.0001;RANDOMNESS_BEST_MIN+=incr_randomness_best_min)
		for(RANDOMNESS_BEST_MAX=min_randomness_best_max;RANDOMNESS_BEST_MAX<=max_randomness_best_max+0.0001;RANDOMNESS_BEST_MAX+=incr_randomness_best_max)
	for(RANDOMNESS_BEST_SINGLE_MIN=min_randomness_best_single_min;RANDOMNESS_BEST_SINGLE_MIN<=max_randomness_best_single_min+0.0001;RANDOMNESS_BEST_SINGLE_MIN+=incr_randomness_best_single_min)
		for(RANDOMNESS_BEST_MAX=min_randomness_best_single_max;RANDOMNESS_BEST_MAX<=max_randomness_best_single_max+0.0001;RANDOMNESS_BEST_MAX+=incr_randomness_best_single_max)
	for(RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN=min_randomorcheap_single_min;RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN<=max_randomorcheap_single_min+0.0001;RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN+=incr_randomorcheap_single_min)
		for(RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX=min_randomorcheap_single_max;RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX<=max_randomorcheap_single_max+0.0001;RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX+=incr_randomorcheap_single_max)
	for(RANDOMNESS_RANDOMorCHEAP_GROUP_MIN=min_randomorcheap_group_min;RANDOMNESS_RANDOMorCHEAP_GROUP_MIN<=max_randomorcheap_group_min+0.0001;RANDOMNESS_RANDOMorCHEAP_GROUP_MIN+=incr_randomorcheap_group_min)
		for(RANDOMNESS_RANDOMorCHEAP_GROUP_MAX=min_randomorcheap_group_max;RANDOMNESS_RANDOMorCHEAP_GROUP_MAX<=max_randomorcheap_group_max+0.0001;RANDOMNESS_RANDOMorCHEAP_GROUP_MAX+=incr_randomorcheap_group_max)
			{
				printParameters(TABU_LENGTH, MIN_TABU_LENGTH, MAX_TABU_LENGTH, N_BEST, RANDOMNESS_BEST, RANDOMNESS_BEST_MIN, RANDOMNESS_BEST_MAX, TREND_THRESHOLD_BEST_RANDOM_GROUP, N_BEST_SINGLE, RANDOMNESS_BEST_SINGLE, RANDOMNESS_BEST_SINGLE_MIN, RANDOMNESS_BEST_SINGLE_MAX, TREND_THRESHOLD_BEST_RANDOM_SINGLE, RANDOMNESS_RANDOMorCHEAP_GROUP, RANDOMNESS_RANDOMorCHEAP_GROUP_MIN, RANDOMNESS_RANDOMorCHEAP_GROUP_MAX, RANDOMNESS_RANDOMorCHEAP_SINGLE, RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN, RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX, ALFA, BETA, ITERATION, ITERATION_THRESHOLD, IT_GROUP_BEST_RANDOM, IT_SINGLE_BEST_RANDOM, IT_GROUP_RANDOM, IT_SINGLE_RANDOM, NO_IMPR_DECREASE, DESTROY_THRESHOLD, DESTROY_GROUP, DESTROY_SINGLE, N_TIMESLOT, TEMP_PAR, DIST_PAR, SINGLE_DIST, GROUP_DIST, ITERATIONS_DIST, DYNAMIC_PARAMETERS, DYNAMIC_TABULIST, TABULIST_INCREASING, DYNAMIC_RANDOMNESS_SINGLE, RANDOMNESS_SINGLE_INCREASING, DYNAMIC_RANDOMNESS_GROUP, RANDOMNESS_GROUP_INCREASING, DYNAMIC_RANDOMorCHEAP_SINGLE, RANDOMorCHEAP_SINGLE_INCREASING, DYNAMIC_RANDOMorCHEAP_GROUP, RANDOMorCHEAP_GROUP_INCREASING, DESTROY_CURRENTorBEST, DESTROY_BESTFIRSTorRANDOM);
				system(command);
				BestPenalty = computeBestPenalty(sol_name, x, n, E, T, S);
				fprintf(output, "%d,%d,%f,%f,%f,%f,%f,%f,%f,%f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%f\n"
					,MIN_TABU_LENGTH,MAX_TABU_LENGTH,RANDOMNESS_BEST_MIN,RANDOMNESS_BEST_MAX,RANDOMNESS_BEST_SINGLE_MIN,RANDOMNESS_BEST_SINGLE_MAX,RANDOMNESS_RANDOMorCHEAP_GROUP_MIN,RANDOMNESS_RANDOMorCHEAP_GROUP_MAX,RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN,RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX,IT_GROUP_BEST_RANDOM,IT_SINGLE_BEST_RANDOM,DESTROY_THRESHOLD,TABULIST_INCREASING,RANDOMNESS_SINGLE_INCREASING,RANDOMNESS_GROUP_INCREASING,RANDOMorCHEAP_SINGLE_INCREASING,RANDOMorCHEAP_GROUP_INCREASING,DESTROY_CURRENTorBEST,DESTROY_BESTFIRSTorRANDOM,BestPenalty);
			}

	return 0;
}
void setup(char *instance_name, int *T_P, int *E_P, int *S_P, int ***conflictual_students_P, int **x_P)
{
	int i, j, k;
	int **enrolled_stud;
	char line[100];
	FILE *fp;
	static const long max_len = 99 + 1;
	char buf[max_len + 1];
	char *last_newline, *last_line;
	int index;

	// .slo
	strcpy(line, instance_name);
	if((fp = fopen(strcat(line, ".slo"), "r")) == NULL)
	{
		fprintf(stdout, "Error: file %s.slo not found.", instance_name);
		return;
	}
	fscanf(fp, "%d", T_P);
	fclose(fp);

	// .exm
	strcpy(line, instance_name);
	if((fp = fopen(strcat(line, ".exm"), "rb")) == NULL)
	{
		fprintf(stdout, "Error: file %s.exm not found.", instance_name);
		return;
	}
	//read that many bytes from the end of the file
	fseek(fp, -max_len, SEEK_END);
	fread(buf, max_len-1, 1, fp);

	//add the null terminator
	buf[max_len-1] = '\0';

	//find the last newline character
	last_newline = strrchr(buf, '\n');
	//extract its index
	index = (int) abs(buf-last_newline);
	//if index is too close to the end skip it (account for eventual extra newline at the end)
	while(abs(max_len-index)<5){
		buf[index]='\0';
		last_newline = strrchr(buf, '\n');
		index = (int) abs(buf-last_newline);
	}

	//cut the very last line, right after the last newline
	last_line = last_newline+1;

	//extract the needed data
	sscanf(last_line, "%d %*d", E_P);

	fclose(fp);

	*x_P = malloc(*E_P * sizeof(int));

	// .stu
	strcpy(line, instance_name);
	if((fp = fopen(strcat(line, ".stu"), "rb")) == NULL)
	{
		fprintf(stdout, "Error: file %s.stu not found.", instance_name);
		return;
	}

	//read that many bytes from the end of the file
	fseek(fp, -max_len, SEEK_END);
	fread(buf, max_len-1, 1, fp);

	//add the null terminator
	buf[max_len-1] = '\0';

	//add the null terminator
		buf[max_len-1] = '\0';

	//find the last newline character
	last_newline = strrchr(buf, '\n');
	//extract its index
	index = (int) abs(buf-last_newline);
	//if index is too close to the end skip it (account for eventual extra newline at the end)
	while(abs(max_len-index)<5){
		buf[index]='\0';
		last_newline = strrchr(buf, '\n');
		index = (int) abs(buf-last_newline);
	}

	//cut the very last line, right after the last newline
	last_line = last_newline+1;

	//extract the needed data
	sscanf(last_line, "s%d %*d", S_P);

	enrolled_stud = malloc(*S_P * sizeof(int*));
	for(i=0; i<*S_P; i++)
		enrolled_stud[i] = calloc(*E_P, sizeof(int));

	fp = freopen(line, "r", fp);
	while(fgets(line, 99, fp) != NULL)
	{
		sscanf(line, "s%d %d\n", &i, &j);
		enrolled_stud[i-1][j-1]++;
	}
	fclose(fp);

	*conflictual_students_P = malloc(*E_P * sizeof(int*));
	for(i=0; i<*E_P; i++)
		(*conflictual_students_P)[i] = calloc(*E_P, sizeof(int));
	for(k=0; k<*S_P; k++)
	{
		for(i=0; i<*E_P; i++)
		{
			for(j=i+1; j<*E_P; j++)
			{
				if(enrolled_stud[k][i] >= 1 && enrolled_stud[k][j] >= 1)
				{
					(*conflictual_students_P)[i][j]++;
					(*conflictual_students_P)[j][i]++;
				}
			}
		}
	}

#ifdef DEBUG_MAIN
	fprintf(stdout, "Number of exams: %d\n", *E_P);
	fprintf(stdout, "Number of timeslots: %d\n\n", *T_P);
	fprintf(stdout, "Students per exam:\n");
	for(i=0; i<*E_P; i++)
		fprintf(stdout, "Exam %d: students %d\n", i+1, (*students_per_exam_P)[i]);
	fprintf(stdout, "\nConflictual students:\n");
	for(i=0; i<*E_P; i++)
	{
		fprintf(stdout, "Exam %d:", i+1);
		for(j=0; j<*E_P; j++)
			fprintf(stdout, "%d ", (*conflictual_students_P)[i][j]);
		fprintf(stdout, "\n");
	}
#endif

	for(i=0; i<*S_P; i++)
		free(enrolled_stud[i]); // not useful anymore
	free(enrolled_stud);
	return;
}
void printParameters(int TABU_LENGTH, int MIN_TABU_LENGTH, int MAX_TABU_LENGTH, int N_BEST, double RANDOMNESS_BEST, double RANDOMNESS_BEST_MIN, double RANDOMNESS_BEST_MAX, double TREND_THRESHOLD_BEST_RANDOM_GROUP, int N_BEST_SINGLE, double RANDOMNESS_BEST_SINGLE, double RANDOMNESS_BEST_SINGLE_MIN, double RANDOMNESS_BEST_SINGLE_MAX, double TREND_THRESHOLD_BEST_RANDOM_SINGLE, double RANDOMNESS_RANDOMorCHEAP_GROUP, double RANDOMNESS_RANDOMorCHEAP_GROUP_MIN, double RANDOMNESS_RANDOMorCHEAP_GROUP_MAX, double RANDOMNESS_RANDOMorCHEAP_SINGLE, double RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN, double RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX, double ALFA, double BETA, int ITERATION, int ITERATION_THRESHOLD, int IT_GROUP_BEST_RANDOM, int IT_SINGLE_BEST_RANDOM, int IT_GROUP_RANDOM, int IT_SINGLE_RANDOM, int NO_IMPR_DECREASE, int DESTROY_THRESHOLD, int DESTROY_GROUP, int DESTROY_SINGLE, int N_TIMESLOT, double TEMP_PAR, double DIST_PAR, int SINGLE_DIST, int GROUP_DIST, int ITERATIONS_DIST, int DYNAMIC_PARAMETERS, int DYNAMIC_TABULIST, int TABULIST_INCREASING, int DYNAMIC_RANDOMNESS_SINGLE, int RANDOMNESS_SINGLE_INCREASING, int DYNAMIC_RANDOMNESS_GROUP, int RANDOMNESS_GROUP_INCREASING, int DYNAMIC_RANDOMorCHEAP_SINGLE, int RANDOMorCHEAP_SINGLE_INCREASING, int DYNAMIC_RANDOMorCHEAP_GROUP, int RANDOMorCHEAP_GROUP_INCREASING, int DESTROY_CURRENTorBEST, int DESTROY_BESTFIRSTorRANDOM)
{
	FILE *fp = fopen("parameters.txt", "w");
	if(fp==NULL)
	{
		fprintf(stderr, "Errore nella scrittura del file parameters.txt\n");
		exit(1);
	}
	fprintf(fp, "TABU_LENGTH %d\n\
MIN_TABU_LENGTH %d\n\
MAX_TABU_LENGTH %d\n\
N_BEST %d\n\
RANDOMNESS_BEST %f\n\
RANDOMNESS_BEST_MIN %f\n\
RANDOMNESS_BEST_MAX %f\n\
TREND_THRESHOLD_BEST_RANDOM_GROUP %f\n\
N_BEST_SINGLE %d\n\
RANDOMNESS_BEST_SINGLE %f\n\
RANDOMNESS_BEST_SINGLE_MIN %f\n\
RANDOMNESS_BEST_SINGLE_MAX %f\n\
TREND_THRESHOLD_BEST_RANDOM_SINGLE %f\n\
RANDOMNESS_RANDOMorCHEAP_GROUP %f\n\
RANDOMNESS_RANDOMorCHEAP_GROUP_MIN %f\n\
RANDOMNESS_RANDOMorCHEAP_GROUP_MAX %f\n\
RANDOMNESS_RANDOMorCHEAP_SINGLE %f\n\
RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN %f\n\
RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX %f\n\
ALFA %f\n\
BETA %f\n\
ITERATION %d\n\
ITERATION_THRESHOLD %d\n\
IT_GROUP_BEST_RANDOM %d\n\
IT_SINGLE_BEST_RANDOM %d\n\
IT_GROUP_RANDOM %d\n\
IT_SINGLE_RANDOM %d\n\
NO_IMPR_DECREASE %d\n\
DESTROY_THRESHOLD %d\n\
DESTROY_GROUP %d\n\
DESTROY_SINGLE %d\n\
N_TIMESLOT %d\n\
TEMP_PAR %f\n\
DIST_PAR %f\n\
SINGLE_DIST %d\n\
GROUP_DIST %d\n\
ITERATIONS_DIST %d\n\
DYNAMIC_PARAMETERS %d\n\
DYNAMIC_TABULIST %d\n\
TABULIST_INCREASING %d\n\
DYNAMIC_RANDOMNESS_SINGLE %d\n\
RANDOMNESS_SINGLE_INCREASING %d\n\
DYNAMIC_RANDOMNESS_GROUP %d\n\
RANDOMNESS_GROUP_INCREASING %d\n\
DYNAMIC_RANDOMorCHEAP_SINGLE %d\n\
RANDOMorCHEAP_SINGLE_INCREASING %d\n\
DYNAMIC_RANDOMorCHEAP_GROUP %d\n\
RANDOMorCHEAP_GROUP_INCREASING %d\n\
DESTROY_CURRENTorBEST %d\n\
DESTROY_BESTFIRSTorRANDOM %d", TABU_LENGTH, MIN_TABU_LENGTH, MAX_TABU_LENGTH, N_BEST, RANDOMNESS_BEST, RANDOMNESS_BEST_MIN, RANDOMNESS_BEST_MAX, TREND_THRESHOLD_BEST_RANDOM_GROUP, N_BEST_SINGLE, RANDOMNESS_BEST_SINGLE, RANDOMNESS_BEST_SINGLE_MIN, RANDOMNESS_BEST_SINGLE_MAX, TREND_THRESHOLD_BEST_RANDOM_SINGLE, RANDOMNESS_RANDOMorCHEAP_GROUP, RANDOMNESS_RANDOMorCHEAP_GROUP_MIN, RANDOMNESS_RANDOMorCHEAP_GROUP_MAX, RANDOMNESS_RANDOMorCHEAP_SINGLE, RANDOMNESS_RANDOMorCHEAP_SINGLE_MIN, RANDOMNESS_RANDOMorCHEAP_SINGLE_MAX, ALFA, BETA, ITERATION, ITERATION_THRESHOLD, IT_GROUP_BEST_RANDOM, IT_SINGLE_BEST_RANDOM, IT_GROUP_RANDOM, IT_SINGLE_RANDOM, NO_IMPR_DECREASE, DESTROY_THRESHOLD, DESTROY_GROUP, DESTROY_SINGLE, N_TIMESLOT, TEMP_PAR, DIST_PAR, SINGLE_DIST, GROUP_DIST, ITERATIONS_DIST, DYNAMIC_PARAMETERS, DYNAMIC_TABULIST, TABULIST_INCREASING, DYNAMIC_RANDOMNESS_SINGLE, RANDOMNESS_SINGLE_INCREASING, DYNAMIC_RANDOMNESS_GROUP, RANDOMNESS_GROUP_INCREASING, DYNAMIC_RANDOMorCHEAP_SINGLE, RANDOMorCHEAP_SINGLE_INCREASING, DYNAMIC_RANDOMorCHEAP_GROUP, RANDOMorCHEAP_GROUP_INCREASING, DESTROY_CURRENTorBEST, DESTROY_BESTFIRSTorRANDOM);
	fclose(fp);
}
void configure(int* min_destroy_threshold, int* max_destroy_threshold,
		int* incr_destroy_thresold, int* min_min_tabu_length,
		int* max_min_tabu_length, int* incr_min_tabu_length,
		int* min_max_tabu_length, int* max_max_tabu_length,
		int* incr_max_tabu_length, int* min_destroy_currentorbest,
		int* max_destroy_currentorbest, int* min_destroy_bestfirstorrandom,
		int* max_destroy_bestrfirstorrandom,
		int* min_randomorcheap_single_increasing,
		int* max_randomorcheap_single_increasing,
		int* min_randomorcheap_group_increasing,
		int* max_randomorcheap_group_increasing, int* min_it_group_best_random,
		int* max_it_group_best_random, int* incr_it_group_best_random,
		int* min_it_single_best_random,
		int* max_it_single_best_random,
		int* incr_it_single_best_random, double* min_randomness_best_min,
		double* max_randomness_best_min, double* incr_randomness_best_min,
		double* min_randomness_best_max, double* max_randomness_best_max,
		double* incr_randomness_best_max,
		double* min_randomness_best_single_min,
		double* max_randomness_best_single_min,
		double* incr_randomness_best_single_min,
		double* min_randomness_best_single_max,
		double* max_randomness_best_single_max,
		double* incr_randomness_best_single_max,
		double* min_randomorcheap_single_min,
		double* max_randomorcheap_single_min,
		double* incr_randomorcheap_single_min,
		double* min_randomorcheap_single_max,
		double* max_randomorcheap_single_max,
		double* incr_randomorcheap_single_max,
		double* min_randomorcheap_group_min,
		double* max_randomorcheap_group_min,
		double* incr_randomorcheap_group_min,
		double* min_randomorcheap_group_max,
		double* max_randomorcheap_group_max,
		double* incr_randomorcheap_group_max)
{
	char line[100], par[50];
	float val;
	FILE* fp = fopen("configure.txt", "r");
	if(fp == NULL)
	{
		fprintf(stderr, "Errore nell'apertura di configure.txt\n");
		exit(2);
	}
	while(fgets(line, 99, fp) != NULL)
	{
		if(strlen(line) == 0)
			continue;
		sscanf(line, "%s %f", par, &val);
		if(!strcmp(par, "min_destroy_threshold"))
			*min_destroy_threshold = val;
		else if(!strcmp(par, "max_destroy_threshold"))
			*max_destroy_threshold = val;
		else if(!strcmp(par, "incr_destroy_thresold"))
			*incr_destroy_thresold = val;
		else if(!strcmp(par, "min_min_tabu_length"))
			*min_min_tabu_length = val;
		else if(!strcmp(par, "max_min_tabu_length"))
			*max_min_tabu_length = val;
		else if(!strcmp(par, "incr_min_tabu_length"))
			*incr_min_tabu_length = val;
		else if(!strcmp(par, "min_max_tabu_length"))
			*min_max_tabu_length = val;
		else if(!strcmp(par, "max_max_tabu_length"))
			*max_max_tabu_length = val;
		else if(!strcmp(par, "incr_max_tabu_length"))
			*incr_max_tabu_length = val;
		else if(!strcmp(par, "min_destroy_currentorbest"))
			*min_destroy_currentorbest = val;
		else if(!strcmp(par, "max_destroy_currentorbest"))
			*max_destroy_currentorbest = val;
		else if(!strcmp(par, "min_destroy_bestfirstorrandom"))
			*min_destroy_bestfirstorrandom = val;
		else if(!strcmp(par, "max_destroy_bestrfirstorrandom"))
			*max_destroy_bestrfirstorrandom = val;
		else if(!strcmp(par, "min_randomorcheap_single_increasing"))
			*min_randomorcheap_single_increasing = val;
		else if(!strcmp(par, "max_randomorcheap_single_increasing"))
			*max_randomorcheap_single_increasing = val;
		else if(!strcmp(par, "min_randomorcheap_group_increasing"))
			*min_randomorcheap_group_increasing = val;
		else if(!strcmp(par, "max_randomorcheap_group_increasing"))
			*max_randomorcheap_group_increasing = val;
		else if(!strcmp(par, "min_it_group_best_random"))
			*min_it_group_best_random = val;
		else if(!strcmp(par, "max_it_group_best_random"))
			*max_it_group_best_random = val;
		else if(!strcmp(par, "incr_it_group_best_random"))
			*incr_it_group_best_random = val;
		else if(!strcmp(par, "min_it_single_best_random"))
			*min_it_single_best_random = val;
		else if(!strcmp(par, "max_it_single_best_random"))
			*max_it_single_best_random = val;
		else if(!strcmp(par, "incr_it_single_best_random"))
			*incr_it_single_best_random = val;
		else if(!strcmp(par, "min_randomness_best_min"))
			*min_randomness_best_min = val;
		else if(!strcmp(par, "max_randomness_best_min"))
			*max_randomness_best_min = val;
		else if(!strcmp(par, "incr_randomness_best_min"))
			*incr_randomness_best_min = val;
		else if(!strcmp(par, "min_randomness_best_max"))
			*min_randomness_best_max = val;
		else if(!strcmp(par, "max_randomness_best_max"))
			*max_randomness_best_max = val;
		else if(!strcmp(par, "incr_randomness_best_max"))
			*incr_randomness_best_max = val;
		else if(!strcmp(par, "min_randomness_best_single_min"))
			*min_randomness_best_single_min = val;
		else if(!strcmp(par, "max_randomness_best_single_min"))
			*max_randomness_best_single_min = val;
		else if(!strcmp(par, "incr_randomness_best_single_min"))
			*incr_randomness_best_single_min = val;
		else if(!strcmp(par, "min_randomness_best_single_max"))
			*min_randomness_best_single_max = val;
		else if(!strcmp(par, "max_randomness_best_single_max"))
			*max_randomness_best_single_max = val;
		else if(!strcmp(par, "incr_randomness_best_single_max"))
			*incr_randomness_best_single_max = val;
		else if(!strcmp(par, "min_randomorcheap_single_min"))
			*min_randomorcheap_single_min = val;
		else if(!strcmp(par, "max_randomorcheap_single_min"))
			*max_randomorcheap_single_min = val;
		else if(!strcmp(par, "incr_randomorcheap_single_min"))
			*incr_randomorcheap_single_min = val;
		else if(!strcmp(par, "min_randomorcheap_single_max"))
			*min_randomorcheap_single_max = val;
		else if(!strcmp(par, "max_randomorcheap_single_max"))
			*max_randomorcheap_single_max = val;
		else if(!strcmp(par, "incr_randomorcheap_single_max"))
			*incr_randomorcheap_single_max = val;
		else if(!strcmp(par, "min_randomorcheap_group_min"))
			*min_randomorcheap_group_min = val;
		else if(!strcmp(par, "max_randomorcheap_group_min"))
			*max_randomorcheap_group_min = val;
		else if(!strcmp(par, "incr_randomorcheap_group_min"))
			*incr_randomorcheap_group_min = val;
		else if(!strcmp(par, "min_randomorcheap_group_max"))
			*min_randomorcheap_group_max = val;
		else if(!strcmp(par, "max_randomorcheap_group_max"))
			*max_randomorcheap_group_max = val;
		else if(!strcmp(par, "incr_randomorcheap_group_max"))
			*incr_randomorcheap_group_max = val;
	}
}
double computeBestPenalty(char *sol_name, int *x, int **n, int E, int T, int S)
{
	int pen = 0;
	int i, j;
	FILE *sol = fopen(sol_name, "r");
	if(sol==NULL)
	{
		fprintf(stderr, "Errore nell'apertura della soluzione %s.\n", sol_name);
		exit(4);
	}
	while(fscanf(sol, "%d %d", &i, &j) != EOF)
	{
		x[i-1] = j-1;
	}
	for(i=0; i<E; i++)
	{
		if(x[i] >= T)
		{
			fprintf(stderr, "Timeslot non valido: x[%d] = %d (T = %d)\n", i, x[i], T);
			exit(5);
		}
		for(j=i+1; j<E; j++)
		{
			if(x[i] == x[j] && n[i][j])
			{
				fprintf(stderr, "Conflitto!! x[%d]=x[%d]=%d e n[%d][%d]=%d\n", i, j, x[i], i, j, n[i][j]);
				exit(6);
			}
			if(abs(x[i]-x[j])<=5 && n[i][j])
				pen += (int) pow(2, 5-abs(x[i]-x[j]))*n[i][j];
		}
	}
	return pen/(double)S;
}
